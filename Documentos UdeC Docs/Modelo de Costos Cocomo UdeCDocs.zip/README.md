SRS-IEEE
========

A Latex template for a Software Requirements Specification that respects the IEEE standards.

## Credits

- [Yiannis Lazarides](http://tex.stackexchange.com/users/963/yiannis-lazarides) for his answer for a stackexchange's question :
http://tex.stackexchange.com/questions/42602/software-requirements-specification-with-latex
- [Karl E. Wiegers](http://karlwiegers.com) for his template :
http://www.se.rit.edu/~emad/teaching/slides/srs_template_sep14.pdf
- [Ken Rimlinger](https://nurupoga.org) for his help on srs-tex
- [François Charoy](http://www.loria.fr/~charoy/) for suggesting me to host srs-tex on Github and distributing it to Telecom Nancy students
